class HaloGeneric {
    SapaUser(x) {
      console.log(`Halo user ${x}`);
    }
  }
  
  const halo = new HaloGeneric();
  
  halo.SapaUser("Ganesha Gibran");
  
  console.log("=== Code Execution Successful ===");